# -*- coding: utf-8 -*-

# -- Sheet --

print("analiza pakietu numpy")

import numpy as np

lista = np.array([2,1,7,8.0,11])
print(lista)

lista = np.array([[2,6,7],[4,8,11],[12,45,6]])
print(lista)



# <i>Tablice w numpy.</i> <br>**Ciąg dalszy**


np.zeros(4)

ar = np.ones(7)
print(ar)
ar

np.empty(5)

u = np.arange(16)
print(u)

u = np.arange(2,89,3)
print(u)

u = np.linspace(0,10,num=5)
print(u)

lista = np.array([34,8,9,12,3,16,77,100,-6,45,6,17,1,233,0,-9,33,2])

print(lista)

nwlista = np.sort(lista)
print(nwlista)

np.sort(lista)
print(lista)

liczba = [45,2,7,12,33]
liczba.sort()
print(liczba)

a = np.array([1,5,8,11])
b = np.array([2,5,9,11])
c = np.array([34,88])
big = np.concatenate((a,b,c))
print(big)

x = np.array([[3,4],[7,17]])
y = np.array([[1,99]])

p = np.concatenate((x,y),axis=0)
print(p)

prosta = np.arange(12)
print(prosta)

npr = prosta.reshape(3,4)
print(npr)

ar = np.array([1,6,17,9,13,49])
print(ar.shape)

print(ar[:3])
print(ar[4:])

print(ar[:len(ar)-3])
print(ar[:-3])

print(ar[::-1])
print(ar[1::2])

w = np.array([[1,2,3,4],[8,9,10,11],[15,17,19,21]])
print(w)

print(w[w<9])

pc = (w>=6)
print(w[pc])
pc = w[w%2==0]
print(pc)
c = w[(w>2)&(w<15)]
print(c)
print(w[(w>7) | (w==4)])

x = np.arange(1,25).reshape(6,4)
print(x)

dane = np.array([1,3,7])
ones = np.ones(3,dtype=int)
tw = np.array([2,2,2])

print(dane+ones)

print(dane-tw)
print(dane*tw)
print(dane/tw)
print(ones/tw)

print(dane.sum())

tab = np.array([[1,8],[23,9]])
print(tab)

print(tab.sum(axis=0))
print(tab.sum(axis=1))
print(tab*1.8)

print(tab.max())
print(tab.min())



