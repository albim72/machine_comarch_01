# -*- coding: utf-8 -*-

# -- Sheet --

import numpy as np
from io import StringIO

dane = u" 1 2 3\n 5 7 83\n 240 923 4"
t = np.genfromtxt(StringIO(dane), delimiter=" ")
print(t)

dane = u"1,2,3\n116,78,19"
t = np.genfromtxt(StringIO(dane), delimiter=",")
print(t)

dane = u"""#
#komentarz....
1, 6
34, 8
12, 90 #trzecia linia
9, 1
#pusta linia
10, 0

"""

t = np.genfromtxt(StringIO(dane),comments="#", delimiter=",")
print(t)

