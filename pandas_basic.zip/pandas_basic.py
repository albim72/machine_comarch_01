# -*- coding: utf-8 -*-

# -- Sheet --

import numpy as np
import pandas as pd

sr = pd.Series([1,2,8,np.nan,17,9])
print(sr)

daty = pd.date_range("20220112",periods=6)
daty

df = pd.DataFrame(np.random.rand(6,4),index=daty,columns=list("ABCD"))
df

s = "lajkonik"
print(s)
print(s[0])
print(s[-1])
print(s[2:5])

df.head(3)

df.tail(4)

df.index

df.columns

e = df.to_numpy()
print(e)

df.describe()

df.T

df.sort_index(axis=1,ascending=False)

df.sort_values(by="B")

df["A"]

df[0:3]

df["20220113":"20220115"]

df.iloc[3]

df.iloc[3:5,0:2]

df.iloc[[1,2,4],[0,2]]

df.iloc[1,1]

df[df["A"]>0.3]

df2 = df.copy()

df2["E"] = ["jeden","dwa","trzy","cztery","pięć","sześć"]
df2

np2 = df2.to_numpy()
print(np2)
print(type(np2))

df2[df2["E"].isin(["dwa","cztery"])]

df.to_csv('dn.csv')

dnframe = pd.read_csv('dn.csv')

dnframe

dnframe = pd.read_csv('dn.csv', index_col=0)

dnframe

